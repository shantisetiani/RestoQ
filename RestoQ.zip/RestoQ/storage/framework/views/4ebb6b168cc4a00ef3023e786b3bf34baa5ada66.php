<?php $__env->startSection('content'); ?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<h1 class="title">Reservation History</h1>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<table class="dataTable stripe hover" id="table">
		<thead>
			<tr>
				<th>Restaurant Name</th>
				<th>Table</th>
				<th>Reservation Time</th>
				<th>On Behalf of</th>
				<th>Contact</th>
			</tr>
		</thead>
		<tbody id="tableContent">
		<?php foreach($rsv as $r): ?>
			<tr>
				<td><?php echo e($r->restaurant_name); ?></td>
				<td><?php echo e($r->table); ?></td>
				<td><?php echo e($r->reservation_time); ?></td>
				<td><?php echo e($r->on_behalf_of); ?></td>
				<td><?php echo e($r->phone); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#table').DataTable();

        var tblContent = document.getElementById("tableContent");

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>