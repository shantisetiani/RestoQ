<?php $__env->startSection('content'); ?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<h1 class="title">Reservation</h1>
</div>
<form class="reservationForm">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
			<label>Name</label>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
			<input type="text" name="" class="formText">
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
	</div>

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
			<label>Phone Number</label>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
			<input type="text" name="" class="formText">
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
	</div>

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
			<label>Address</label>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
			<textarea class="formText"></textarea>
		</div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
	</div>

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
			<label>Reservation Time</label>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
			<input type="datetime-local" name="" class="formText">
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
			<a href="#popup-table" class="popup-link">Choose Table</a>
		</div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
	</div>

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8"></div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
	    	<input type="submit" class="btn btn-primary" value="Reserve" id="btnReserve">
		</div>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"></div>
	</div>

	<div class="popup-wrapper" id="popup-table">
		<div class="popup-container">
			<a class="popup-close" href="#closed">X</a>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>2 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>8 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>6 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>2 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>8 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>2 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>6 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>8 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>4 orang</span>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<div class="RestoTable">
					<span>2 orang</span>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>