<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Insert</h2>
    <form action="/insert">
        Username : <input type="text" name="username"><br>
        Fullname : <input type="text" name="fullname"><br>
        Password : <input type="password" name="password"><br>
        <input type="submit" value="Insert">
    </form>

    <h2>Update</h2>
    <form action="/update">
        ID : <input type="text" name="id"><br>
        Fullname : <input type="text" name="fullname"><br>
        <input type="submit" value="Update">
    </form>

    <h2>Delete</h2>
    <form action="/delete">
        ID : <input type="text" name="id"><br>
        <input type="submit" value="Delete">
    </form>

    <?php if(isset($datas)): ?>
        <?php foreach($datas as $data): ?>
            <?php echo e("Username : ".$data->username); ?>

            <br>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>