<?php $__env->startSection('content'); ?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-bottom: 35px;">
	<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
		<img src="img/restaurant/KFC.jpg" class="img-responsive">
	</div>
	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" align="left">
		<h2 style="color:#902724;">Kentucky Fried Chicken</h2>
		<h4>Fast Food</h4>
	</div>
	<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" align="right">
		<a href="<?php echo e(url('/reserve')); ?>"><input type="button" value="Reserve"></a>
	</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="navbar detailBoxHeader">
			<ul class="hide-on-med-and-down">
				<li class="col-xs-4 col-sm-4 col-md-4 col-lg-4 center" id="tabContact"><a class="tab" onclick="showContact()">Contact</a></li>
				<li class="col-xs-4 col-sm-4 col-md-4 col-lg-4 center" id="tabMenu"><a class="tab" onclick="showMenu()">Menu</a></li>
				<li class="col-xs-4 col-sm-4 col-md-4 col-lg-4 center" id="tabReview"><a class="tab" onclick="showReview()">Review</a></li>
			</ul>
		</div>
	</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="restaurantDetailContent">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div id="contactContent" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 detailBoxContent">
			<div style="margin-bottom:4%;">
				<h5><img src="img/phone.png" class="img-responsive" width="3%">14022</h5>
				<h5><img src="img/mail.png" class="img-responsive" width="3%">info@kfcindonesia.com</h5>
			</div>
			<div>
				<iframe width="600" height="450" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=KFC%20kemanggisan&key=AIzaSyC6h1z5zbgzzrX3FAUaDqf_hHvi1uBZDwo" allowfullscreen></iframe>
				<h5>Jl. Kebon Jeruk Raya no. 8 <br> Kebon Jeruk, Jakarta Barat</h5>
			</div>
		</div>
		<div id="menuContent" style="display:none;" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 detailBoxContent detailBoxContent">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 menu">
				<h3>Main Course</h3>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/ayamKFC.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Ayam</label><br>
							<label style="font-size:20px;">Rp10.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/spaghettiKFC.png" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Spaghetti</label><br>
							<label style="font-size:20px;">Rp20.000,-</label>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/burger.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Burger</label><br>
							<label style="font-size:20px;">Rp15.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/kentang.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Kentang</label><br>
							<label style="font-size:20px;">Rp7.000,-</label>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/creamSoup.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Cream Soup</label><br>
							<label style="font-size:20px;">Rp10.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/soup.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Soup</label><br>
							<label style="font-size:20px;">Rp10.000,-</label>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 menu">
				<h3>Dessert</h3>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/moltenCake.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Molten Cake</label><br>
							<label style="font-size:20px;">Rp10.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/pudding.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Pudding</label><br>
							<label style="font-size:20px;">Rp10.000,-</label>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 menu">
				<h3>Drinks</h3>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/cola.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Coca Cola</label><br>
							<label style="font-size:20px;">Rp7.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/iceBlendedCrispyCinno.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Ice Blended Crispy Cinno</label><br>
							<label style="font-size:20px;">Rp20.000,-</label>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/iceBlendedCappucino.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Ice Blended Cappucino</label><br>
							<label style="font-size:20px;">Rp18.000,-</label>
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
							<img src="img/mochaFloat.jpg" class="menuImg">
						</div>
						<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
							<label style="font-size:20px;">Mocha Float</label><br>
							<label style="font-size:20px;">Rp15.000,-</label>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="reviewContent" style="display:none;" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 detailBoxContent">
			<?php for($i=0;$i<5;$i++): ?>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 reviewBox">
				<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
					<h3 class="username">Nama</h3>
					<img src="img/icon/businessman.png" class="img-responsive userPhoto">
				</div>
				<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10" align="left">
					<div style="margin-top: 30px; font-weight: bold; font-size: 18pt;">Title</div>
					<div class="rate">
					  <input type="radio" id="star5" name="rate" value="5" />
					  <label for="star5" title="Very Good">5 stars</label>
					  <input type="radio" id="star4" name="rate" value="4" />
					  <label for="star4" title="Good">4 stars</label>
					  <input type="radio" id="star3" name="rate" value="3" />
					  <label for="star3" title="OK">3 stars</label>
					  <input type="radio" id="star2" name="rate" value="2" />
					  <label for="star2" title="Bad">2 stars</label>
					  <input type="radio" id="star1" name="rate" value="1" />
					  <label for="star1" title="Very Bad">1 star</label>
					</div><br><br><br>
					<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
				</div>
			</div>
			<?php endfor; ?>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 reviewBox">
				<hr>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 reviewBox">
				<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
					<h3 class="username">Nama</h3>
					<img src="img/icon/businessman.png" class="img-responsive userPhoto">
				</div>
				<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10" align="left">
					<div style="margin-top: 10px;"><input type="text" name="" placeholder="Title"></div>
					<div class="rate">
					  <input type="radio" id="star5" name="rate" value="5" />
					  <label for="star5" title="Very Good">5 stars</label>
					  <input type="radio" id="star4" name="rate" value="4" />
					  <label for="star4" title="Good">4 stars</label>
					  <input type="radio" id="star3" name="rate" value="3" />
					  <label for="star3" title="OK">3 stars</label>
					  <input type="radio" id="star2" name="rate" value="2" />
					  <label for="star2" title="Bad">2 stars</label>
					  <input type="radio" id="star1" name="rate" value="1" />
					  <label for="star1" title="Very Bad">1 star</label>
					</div>
					<div><textarea style="resize: none; width: 100%; height:100px;" placeholder="Comment"></textarea></div>
					<div><input type="submit" value="POST" id="btnPost"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>