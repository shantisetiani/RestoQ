<?php $__env->startSection('content'); ?>
<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
	<ul id="myTab" class="nav nav-tabs" role="tablist">
		<li role="presentation" class="active"><a href="#home-main" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">All</a></li>
		<li role="presentation"><a href="#fastfood" role="tab" id="fastfood-tab" data-toggle="tab" aria-controls="fastfood">Fast Food</a></li>
		<li role="presentation"><a href="#chineese" role="tab" id="chineese-tab" data-toggle="tab" aria-controls="chineese">Chineese</a></li>
		<li role="presentation"><a href="#japanese" role="tab" id="japanese-tab" data-toggle="tab" aria-controls="japanese">Japanese</a></li>
		<li role="presentation"><a href="#vegetarian" role="tab" id="vegetarian-tab" data-toggle="tab" aria-controls="vegetarian">Vegetarian</a></li>
	</ul>
	<div id="myTabContent" class="tab-content">
		<div role="tabpanel" class="tab-pane fade in active" id="home-main" aria-labelledby="home-tab">
			<div class="w3_tab_img">
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/Ippudo.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Top Rated Restaurant</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/DharmaKitchen.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <div class="stars">
								  <form action="">
								    <input class="star star-5" id="star-5" type="radio" name="star"/>
								    <label class="star star-5" for="star-5"></label>
								    <input class="star star-4" id="star-4" type="radio" name="star"/>
								    <label class="star star-4" for="star-4"></label>
								    <input class="star star-3" id="star-3" type="radio" name="star"/>
								    <label class="star star-3" for="star-3"></label>
								    <input class="star star-2" id="star-2" type="radio" name="star"/>
								    <label class="star star-2" for="star-2"></label>
								    <input class="star star-1" id="star-1" type="radio" name="star"/>
								    <label class="star star-1" for="star-1"></label>
								  </form>
								</div>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/KFC.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Kentucky Fried Chicken</h3>
							  <div class="stars">
								  <form action="">
								    <input class="star star-5" id="star-5" type="radio" name="star"/>
								    <label class="star star-5" for="star-5"></label>
								    <input class="star star-4" id="star-4" type="radio" name="star"/>
								    <label class="star star-4" for="star-4"></label>
								    <input class="star star-3" id="star-3" type="radio" name="star"/>
								    <label class="star star-3" for="star-3"></label>
								    <input class="star star-2" id="star-2" type="radio" name="star"/>
								    <label class="star star-2" for="star-2"></label>
								    <input class="star star-1" id="star-1" type="radio" name="star"/>
								    <label class="star star-1" for="star-1"></label>
								  </form>
								</div>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/TaWan.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/BurgerKing.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/SushiTei.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/ParadiseDynasty.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/PizzaHut.jpg')); ?>" alt=" " class="restaurantImg" />
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="fastfood" aria-labelledby="fastfood-tab">
			<div class="w3_tab_img">
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/KFC.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/PizzaHut.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/BurgerKing.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="chineese" aria-labelledby="chineese-tab">
			<div class="w3_tab_img">
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/ImperialKitchen.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/ParadiseDynasty.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/TaWan.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="japanese" aria-labelledby="japanese-tab">
			<div class="w3_tab_img">
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/SushiTei.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/Ippudo.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="vegetarian" aria-labelledby="vegetarian-tab">
			<div class="w3_tab_img">
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 w3_tab_img_left">
					<div class="demo">
						<a href="<?php echo e(url('RestaurantDetail')); ?>">
						  <figure class="imghvr-shutter-in-out-diag-2"><img src="<?php echo e(asset('img/restaurant/DharmaKitchen.jpg')); ?>" alt=" " class="restaurantImg">
							<figcaption>
							  <h3>Wind Energy</h3>
							  <p>Phasellus elementum ullamcorper urna, 
								eu rhoncus lacus rutrum non.</p>
							</figcaption>
						  </figure>
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
</div>
	
	<script src="js/jquery.tools.min.js"></script>
	<script src="js/jquery.mobile.custom.min.js"></script>
	<script src="js/jquery.cm-overlay.js"></script>
	<script>
		$(document).ready(function(){
			$('.cm-overlay').cmOverlay();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>