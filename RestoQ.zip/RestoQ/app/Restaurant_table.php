<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Restaurant_table extends Model
{
    //
}
