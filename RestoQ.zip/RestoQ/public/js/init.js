(function($){
  $(function(){

    $('.button-collapse').sideNav();

  }); // end of document ready
})(jQuery); // end of jQuery name space

function setURL(url){
          document.getElementById('iframe').src = url;
      }

      function active1(){
        document.getElementById("ni").className = "collection-item active";
        document.getElementById("si").className = "collection-item";
        document.getElementById("ol").className = "collection-item";
        document.getElementById("yc").className = "collection-item";
        document.getElementById("ppo").className = "collection-item";
        document.getElementById("ao").className = "collection-item";
      }
      function active2(){
        document.getElementById("ni").className = "collection-item";
        document.getElementById("si").className = "collection-item active";
        document.getElementById("ol").className = "collection-item";
        document.getElementById("yc").className = "collection-item";
        document.getElementById("ppo").className = "collection-item";
        document.getElementById("ao").className = "collection-item";
      }
      function active3(){
        document.getElementById("ni").className = "collection-item";
        document.getElementById("si").className = "collection-item";
        document.getElementById("ol").className = "collection-item active";
        document.getElementById("yc").className = "collection-item";
        document.getElementById("ppo").className = "collection-item";
        document.getElementById("ao").className = "collection-item";
      }
      function active4(){
        document.getElementById("ni").className = "collection-item";
        document.getElementById("si").className = "collection-item";
        document.getElementById("ol").className = "collection-item";
        document.getElementById("yc").className = "collection-item active";
        document.getElementById("ppo").className = "collection-item";
        document.getElementById("ao").className = "collection-item";
      }
      function active5(){
        document.getElementById("ni").className = "collection-item";
        document.getElementById("si").className = "collection-item";
        document.getElementById("ol").className = "collection-item";
        document.getElementById("yc").className = "collection-item";
        document.getElementById("ppo").className = "collection-item active";
        document.getElementById("ao").className = "collection-item";
      }
      function active6(){
        document.getElementById("ni").className = "collection-item";
        document.getElementById("si").className = "collection-item";
        document.getElementById("ol").className = "collection-item";
        document.getElementById("yc").className = "collection-item";
        document.getElementById("ppo").className = "collection-item";
        document.getElementById("ao").className = "collection-item active";
      }